# encoding: utf-8
"""agents/planning_agent.py"""
from .base_agent import BaseAgent

class PlanningAgent(BaseAgent):
    name = "Planning Agent"
    role = "Chief Urban Planning Strategist"
    goal = "Create complete 5-zone master plan across all 10 domains"

    def run(self, user_input, context, revision=0):
        pop  = user_input.get("population", 2000000)
        bud  = user_input.get("budget", 850)
        pri  = user_input.get("priority", "traffic")
        p1,p2,p3 = int(bud*0.18),int(bud*0.44),int(bud*0.28)
        green = "25%" if pri=="environment" else "20%"
        rev_note = f"\n⚠️ REVISION {revision}: Budget exceeded — cut Phase 2 by 15%, defer Phase 3." if revision else ""
        rag = self.recall(f"urban master plan zones buildings {pop} population")

        system = f"""You are {self.name} AI Agent.
Role: {self.role}
Goal: {self.goal}
Memory: {rag}
Respond ONLY in valid JSON."""

        user = f"""Complete master plan: pop={pop:,}, budget=Rs {bud}Cr, priority={pri}{rev_note}

Return JSON:
{{
  "agent": "Planning Agent",
  "revision": {revision},
  "react_log": ["PERCEIVE: 10-domain needs received","RECALL: Zone layouts from RAG","REASON: priority={pri} {'REVISION budget cut' if revision else 'standard plan'}","ACT: 5-zone master plan with specific buildings"],
  "city_vision": "Complete smart city for {pop:,} residents — zero congestion, clean air, quality life by 2045",
  "zone_plan": {{
    "ZONE_1_RESIDENTIAL_35pct": ["{pop//20:,} affordable G+7","{pop//33:,} mid-income G+12","Senior living","Community centers"],
    "ZONE_2_COMMERCIAL_20pct": ["3 CBDs","IT park 50Ksqm","2 wholesale + 8 retail markets","Convention center"],
    "ZONE_3_INDUSTRIAL_12pct": ["Eco-park 200 units 150ha","2 logistics hubs","3 MSME clusters"],
    "ZONE_4_GREEN_{green.replace('%','pct')}": ["{max(8,pop//250000)} parks 15ha","28km corridors","2 forests 50ha","Sports complexes"],
    "ZONE_5_INFRASTRUCTURE_13pct": ["18km ring road","3 flyovers","24km BRT","Metro {8 if pop>1500000 else 4}km","Command Center"]
  }},
  "public_buildings": [
    "{max(2,pop//500000)} Hospitals 500-bed — Rs {max(2,pop//500000)*40}Cr",
    "{max(15,pop//20000)} Schools K-12 — Rs {max(15,pop//20000)*5}Cr",
    "{max(4,pop//100000)} Colleges",
    "{max(6,pop//200000)} Police Stations",
    "{max(5,pop//250000)} Fire Stations",
    "City Hall + Ward Offices"
  ],
  "phase_1": {{"duration":"0-6 months","budget":"{p1}","items":["45 AI signals Rs 23Cr","Command Center Rs 35Cr","AQ sensors Rs 8Cr","Road repair Rs {max(0,p1-66)}Cr"]}},
  "phase_2": {{"duration":"6-18 months","budget":"{p2}","items":["3 flyovers Rs 180Cr","24km BRT Rs 145Cr","{max(8,pop//250000)} parks Rs 55Cr","2 hospitals open"]}},
  "phase_3": {{"duration":"18-36 months","budget":"{p3}","items":["Digital Twin Rs 45Cr","Metro ext Rs {(8 if pop>1500000 else 4)*18}Cr","Solar 45MW Rs 67Cr","Housing {pop//20:,} units"]}},
  "rag_insight": "Memory: phased quick-wins builds funding momentum for Phase 2-3"
}}"""

        result = self.parse_json(self.call_llm(system, user)) or {
            "agent":"Planning Agent","revision":revision,
            "react_log":[f"PERCEIVE: 10-domain needs","RECALL: Zone layouts RAG",f"REASON: {pri} {'REVISION' if revision else 'standard'}","ACT: 5-zone plan"],
            "city_vision":f"Complete smart city for {pop:,} by 2045",
            "zone_plan":{
                "ZONE_1_RESIDENTIAL":[f"{pop//20:,} affordable G+7",f"{pop//33:,} G+12","Senior living","Community centers"],
                "ZONE_2_COMMERCIAL":["3 CBDs","IT park","Markets","Convention center"],
                "ZONE_3_INDUSTRIAL":["Eco-park 200 units","Logistics hubs","MSME clusters"],
                "ZONE_4_GREEN":[f"{max(8,pop//250000)} parks","28km corridors","Urban forests"],
                "ZONE_5_INFRA":["18km ring road","3 flyovers","24km BRT",f"Metro {8 if pop>1500000 else 4}km"]
            },
            "public_buildings":[f"{max(2,pop//500000)} Hospitals",f"{max(15,pop//20000)} Schools",f"{max(4,pop//100000)} Colleges","Police + Fire stations","City Hall"],
            "phase_1":{"duration":"0-6m","budget":str(p1),"items":["45 signals","Command Center","AQ sensors","Road repair"]},
            "phase_2":{"duration":"6-18m","budget":str(p2),"items":["3 flyovers","24km BRT","Parks","Hospitals"]},
            "phase_3":{"duration":"18-36m","budget":str(p3),"items":["Digital Twin","Metro","Solar","Housing"]},
            "rag_insight":"Phased approach builds momentum"
        }
        self.memory.add(f"Plan: 5 zones revision={revision} for pop={pop:,}", {"agent":"planning"})
        return result