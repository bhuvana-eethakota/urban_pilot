# encoding: utf-8
"""agents/budget_agent.py"""
from .base_agent import BaseAgent

class BudgetAgent(BaseAgent):
    name = "Budget Agent"
    role = "Municipal Finance Strategist"
    goal = "Validate budget — flag if insufficient, maximize ROI"

    def run(self, user_input, context, **kwargs):
        bud    = user_input.get("budget", 850)
        pri    = user_input.get("priority", "traffic")
        pop    = user_input.get("population", 2000000)
        annual = int(bud * 0.20)
        p1,p2,p3,cont = int(bud*0.18),int(bud*0.44),int(bud*0.28),int(bud*0.10)

        # Get cost estimate from controller pre-calc
        cost_est = context.get("cost_estimate", {})
        full_cost = cost_est.get("full_cost_crore", int(bud * 1.4))
        gap = max(0, full_cost - bud)
        needs_revision = bud < 500

        rag = self.recall(f"Smart Cities Mission PPP funding ROI budget Rs {bud}Cr")

        system = f"""You are {self.name}. Role: {self.role}. Goal: {self.goal}.
Memory: {rag}. Respond ONLY in valid JSON."""

        user = f"""Budget plan: budget=Rs {bud}Cr, full_cost=Rs {full_cost}Cr, gap=Rs {gap}Cr

Return JSON:
{{
  "agent":"Budget Agent",
  "react_log":["PERCEIVE: Budget Rs {bud}Cr full plan Rs {full_cost}Cr","RECALL: SCM covers 47%","REASON: {'GAP Rs '+str(gap)+'Cr revision needed' if needs_revision else 'Adequate Phase1-2'}","ACT: {'FLAG REVISION' if needs_revision else 'Full allocation'}"],
  "budget_analysis":{{"allocated":{bud},"full_cost":{full_cost},"gap":{gap},"verdict":"{'INSUFFICIENT - revision triggered' if needs_revision else 'Adequate - full plan approved'}"}},
  "phase_allocation":[
    {{"phase":"Phase 1","crore":{p1},"items":["AI signals Rs 23Cr","Command Ctr Rs 35Cr","AQ sensors Rs 8Cr","Roads Rs {max(0,p1-66)}Cr"]}},
    {{"phase":"Phase 2","crore":{p2},"items":["3 flyovers Rs 180Cr","BRT Rs 145Cr","Parks Rs 55Cr","Hospitals Rs {int(p2*0.1)}Cr"]}},
    {{"phase":"Phase 3","crore":{p3},"items":["Digital Twin Rs 45Cr","Solar Rs 67Cr","EV Rs 26Cr","Metro Rs {max(0,p3-138)}Cr"]}}
  ],
  "funding":[
    {{"source":"Smart Cities Mission","crore":{int(bud*0.47)},"pct":"47%"}},
    {{"source":"State Fund","crore":{int(bud*0.30)},"pct":"30%"}},
    {{"source":"PPP","crore":{int(bud*0.23)},"pct":"23%"}}
  ],
  "returns":{{"annual_savings":{annual},"roi":"{round(annual*5/bud,1)}x","payback_yrs":"{round(bud/annual,1)}","npv_20yr":{annual*12}}},
  "full_cost_crore":{full_cost},
  "verdict":"{'Phase 3 via PPP — budget covers Phase 1-2 fully' if not needs_revision else 'REVISION: Defer Phase 3, cut Phase 2 20%'}",
  "feedback_flag":{"true" if needs_revision else "false"},
  "feedback_message":"{'BUDGET ALERT Rs '+str(bud)+'Cr needs Rs '+str(full_cost)+'Cr - Planning revision triggered' if needs_revision else 'Budget Rs '+str(bud)+'Cr adequate for Phase 1-2'}"
}}"""

        result = self.parse_json(self.call_llm(system, user)) or {
            "agent":"Budget Agent",
            "react_log":[f"PERCEIVE: Rs {bud}Cr vs Rs {full_cost}Cr","RECALL: SCM 47%",f"REASON: {'Gap' if needs_revision else 'Adequate'}","ACT: Allocation done"],
            "budget_analysis":{"allocated":bud,"full_cost":full_cost,"gap":gap,"verdict":"INSUFFICIENT" if needs_revision else "Adequate"},
            "phase_allocation":[{"phase":"P1","crore":p1,"items":["Signals","Ctr","Sensors","Roads"]},{"phase":"P2","crore":p2,"items":["Flyovers","BRT","Parks","Hospitals"]},{"phase":"P3","crore":p3,"items":["Twin","Solar","EV","Metro"]}],
            "funding":[{"source":"SCM","crore":int(bud*0.47),"pct":"47%"},{"source":"State","crore":int(bud*0.30),"pct":"30%"},{"source":"PPP","crore":int(bud*0.23),"pct":"23%"}],
            "returns":{"annual_savings":annual,"roi":f"{round(annual*5/bud,1)}x","payback_yrs":str(round(bud/annual,1)),"npv_20yr":annual*12},
            "full_cost_crore":full_cost,
            "verdict":"Phase 3 via PPP" if not needs_revision else "REVISION needed",
            "feedback_flag":needs_revision,
            "feedback_message":f"{'ALERT: revision needed' if needs_revision else 'Budget adequate'}"
        }
        self.memory.add(f"Budget Rs {bud}Cr ROI {round(annual*5/bud,1)}x savings Rs {annual}Cr", {"agent":"budget"})
        return result