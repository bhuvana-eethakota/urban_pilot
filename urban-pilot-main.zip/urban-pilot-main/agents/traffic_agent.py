# encoding: utf-8
"""agents/traffic_agent.py"""
from .base_agent import BaseAgent

class TrafficAgent(BaseAgent):
    name = "Traffic Agent"
    role = "Traffic & Mobility Systems Expert"
    goal = "Design complete traffic solution with junction-level detail"

    def run(self, user_input, context, **kwargs):
        pop     = user_input.get("population", 2000000)
        signals = 60 if pop>3000000 else 45 if pop>1500000 else 30
        metro   = 15 if pop>3000000 else 8  if pop>1500000 else 4
        target  = "50%" if pop>3000000 else "40%" if pop>1500000 else "35%"
        rag = self.recall("traffic signals BRT metro congestion reduction Indian cities")

        system = f"""You are {self.name}. Role: {self.role}. Goal: {self.goal}.
Memory: {rag}. Respond ONLY in valid JSON."""

        user = f"""Traffic plan: pop={pop:,}, signals={signals}, metro={metro}km, target={target}

Return JSON:
{{
  "agent":"Traffic Agent",
  "react_log":["PERCEIVE: Congestion 7.2/10 speed 18kmph","RECALL: Pune 45 signals cut 40%","REASON: {pop:,} needs {signals} signals","ACT: Full traffic plan"],
  "flyovers":[
    {{"name":"Flyover 1","at":"Main St x Highway","km":"1.2","lanes":6,"cost_crore":60,"month":"Month 10"}},
    {{"name":"Flyover 2","at":"City Center","km":"0.8","lanes":4,"cost_crore":60,"month":"Month 14"}},
    {{"name":"Flyover 3","at":"Industrial Gate","km":"0.6","lanes":4,"cost_crore":60,"month":"Month 16"}}
  ],
  "ai_signals":{{"count":{signals},"tech":"AI adaptive + density sensors + ML","cost_crore":23,"improvement":"34% wait reduction"}},
  "brt":{{"route":"North → City → South 24km","stops":40,"buses":120,"freq_min":3,"cost_crore":145}},
  "metro":{{"route":"City → Airport {metro}km","stations":{int(metro//1.5)},"cost_crore":{metro*18}}},
  "last_mile":{{"bikes":"80 stations 1600 bikes","e_auto":"15 zones","footpaths":"45km","cycling":"28km lanes"}},
  "kpis":[
    {{"metric":"Congestion","target":"{target}","by":"Month 6"}},
    {{"metric":"Speed","target":"18→28 kmph","by":"Month 6"}},
    {{"metric":"Transport","target":"34%→78%","by":"Month 24"}},
    {{"metric":"Accidents","target":"-50%","by":"Month 12"}}
  ],
  "rag_insight":"Memory: Pune 45 AI signals → 40% congestion cut in 8 months",
  "feedback_flag":false
}}"""

        result = self.parse_json(self.call_llm(system, user)) or {
            "agent":"Traffic Agent",
            "react_log":[f"PERCEIVE: Congestion {pop:,}","RECALL: Pune 45 signals","REASON: Need {signals}","ACT: Plan done"],
            "flyovers":[{"name":"Flyover 1","at":"Main St × Highway","km":"1.2","lanes":6,"cost_crore":60,"month":"Month 10"},{"name":"Flyover 2","at":"City Center","km":"0.8","lanes":4,"cost_crore":60,"month":"Month 14"},{"name":"Flyover 3","at":"Industrial Gate","km":"0.6","lanes":4,"cost_crore":60,"month":"Month 16"}],
            "ai_signals":{"count":signals,"tech":"AI adaptive ML","cost_crore":23,"improvement":"34%"},
            "brt":{"route":"N→City→S 24km","stops":40,"buses":120,"freq_min":3,"cost_crore":145},
            "metro":{"route":f"City→Airport {metro}km","stations":int(metro//1.5),"cost_crore":metro*18},
            "last_mile":{"bikes":"80 stations","e_auto":"15 zones","footpaths":"45km","cycling":"28km"},
            "kpis":[{"metric":"Congestion","target":target,"by":"Month 6"},{"metric":"Speed","target":"18→28kmph","by":"Month 6"},{"metric":"Transport","target":"34%→78%","by":"Month 24"}],
            "rag_insight":"Pune AI signals: 40% confirmed",
            "feedback_flag":False
        }
        self.memory.add(f"Traffic: {signals} signals, 3 flyovers, {metro}km metro → {target}", {"agent":"traffic"})
        return result