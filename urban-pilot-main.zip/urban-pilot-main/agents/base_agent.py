# encoding: utf-8
"""
base_agent.py - Base class for all UrbanPilot agents
Every agent has: name, role, goal, tools access, memory access, LLM
"""
import os, json
from groq import Groq
from dotenv import load_dotenv
load_dotenv()

class BaseAgent:
    name  = "Base Agent"
    role  = "Urban Planning Specialist"
    goal  = "Provide expert analysis"
    model = "llama-3.1-8b-instant"

    def __init__(self):
        self.client = Groq(api_key=os.getenv("GROQ_API_KEY"))
        # Import memory lazily to avoid circular imports
        from memory import memory
        self.memory = memory

    def call_llm(self, system: str, user: str, max_tokens: int = 1400) -> str:
        r = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": system},
                {"role": "user",   "content": user}
            ],
            max_tokens=max_tokens,
            temperature=0.2
        )
        return r.choices[0].message.content

    def parse_json(self, raw: str) -> dict:
        try:
            s = raw.find("{"); e = raw.rfind("}") + 1
            return json.loads(raw[s:e])
        except:
            return None

    def recall(self, query: str) -> str:
        return self.memory.recall_as_string(query, k=3)

    def run(self, user_input: dict, context: dict, **kwargs) -> dict:
        raise NotImplementedError("Each agent must implement run()")