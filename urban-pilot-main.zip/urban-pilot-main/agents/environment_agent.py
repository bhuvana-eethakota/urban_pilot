# encoding: utf-8
"""agents/environment_agent.py"""
from .base_agent import BaseAgent

class EnvironmentAgent(BaseAgent):
    name = "Environment Agent"
    role = "Environmental Sustainability Specialist"
    goal = "Design complete green infrastructure — AQI below 100, WHO green space standard"

    def run(self, user_input, context, **kwargs):
        pri   = user_input.get("priority", "traffic")
        bud   = user_input.get("budget", 850)
        parks = 12 if pri=="environment" else 8
        corr  = 35 if pri=="environment" else 28
        rag   = self.recall("green corridors parks AQI carbon WHO standards urban")

        system = f"""You are {self.name}. Role: {self.role}. Goal: {self.goal}.
Memory: {rag}. Respond ONLY in valid JSON."""

        user = f"""Environmental plan: priority={pri}, parks={parks}, corridors={corr}km

Return JSON:
{{
  "agent":"Environment Agent",
  "react_log":["PERCEIVE: AQI 156 green 4.2sqm vs WHO 9","RECALL: {corr}km corridors 45K tons CO2/yr","REASON: Need {parks} parks + corridors","ACT: Full green plan"],
  "current":{{"aqi":156,"green_sqm":"4.2 (need 9)","deficit":"5.6 sqkm","carbon":"2.8M tons/yr","heat":"+3.2C"}},
  "parks":[
    "Central Park 25ha — fountain amphitheater jogging",
    "North Zone 15ha — children sports courts",
    "South Zone 15ha — lake walking paths",
    "East Buffer 20ha — industrial air purification",
    "West Residential 12ha — community garden",
    "Riverside Promenade 8km waterfront",
    "Heritage Garden 10ha city center",
    "{parks-7} Pocket Parks 2ha each in dense wards"
  ],
  "corridors":{{"km":{corr},"routes":["Main St 8km","Ring Road 12km","Industrial buffer 8km"],"trees":5000,"carbon_offset":"45,000 tons/yr"}},
  "mitigation":[
    {{"action":"{corr}km corridors","offset":"45,000t/yr","cost":18,"phase":1}},
    {{"action":"Rooftop gardens 40%","offset":"32,000t/yr","cost":12,"phase":1}},
    {{"action":"{parks} parks","offset":"28,000t/yr","cost":55,"phase":2}},
    {{"action":"Solar 45MW","offset":"38,000t/yr","cost":67,"phase":3}}
  ],
  "targets":{{"aqi":"Below 100 Month 18","green":"9 sqm/person Month 24","carbon":"-30% 2030"}},
  "rag_insight":"Memory: corridors + parks achieve WHO green standard in 24 months",
  "feedback_flag":false
}}"""

        result = self.parse_json(self.call_llm(system, user)) or {
            "agent":"Environment Agent",
            "react_log":["PERCEIVE: AQI 156 4.2sqm","RECALL: Corridors 45K tons","REASON: Need parks+corridors","ACT: Green plan done"],
            "current":{"aqi":156,"green_sqm":"4.2","deficit":"5.6sqkm","carbon":"2.8M tons","heat":"+3.2C"},
            "parks":["Central 25ha","North 15ha","South 15ha","East Buffer 20ha","West 12ha","Riverside 8km","Heritage 10ha","Pocket parks"],
            "corridors":{"km":corr,"routes":["Main St 8km","Ring Rd 12km","Industrial 8km"],"trees":5000,"carbon_offset":"45,000t/yr"},
            "mitigation":[{"action":f"{corr}km corridors","offset":"45K","cost":18,"phase":1},{"action":"Rooftop 40%","offset":"32K","cost":12,"phase":1},{"action":f"{parks} parks","offset":"28K","cost":55,"phase":2}],
            "targets":{"aqi":"Below 100 Month 18","green":"9 sqm Month 24","carbon":"-30% 2030"},
            "rag_insight":"Parks + corridors achieve WHO standard 24 months",
            "feedback_flag":False
        }
        self.memory.add(f"Environment: {parks} parks {corr}km corridors AQI 156→100", {"agent":"environment"})
        return result